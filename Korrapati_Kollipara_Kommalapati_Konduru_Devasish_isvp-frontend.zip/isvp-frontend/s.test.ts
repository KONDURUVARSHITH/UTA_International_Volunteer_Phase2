
// Import the required modules
import { act, renderHook } from '@testing-library/react-hooks';
import useFetchHook from ' ./index';

// Mock the fetch function
global.fetch = jest.fn();
// Define some test data
const mockTodo = {
    id: 1,
    title: 'Test todo',
    completed: false
};
const mockPath = 'https://jsonplaceholder.typicode.com/todos/1';
const mockOptions = {
    method: 'GET',
    headers: {
        'Content-Type': 'application/json'
    }
};
// Define a helper function to wait for next tick
const waitForNextTick = () => new Promise((resolve) => setTimeout(resolve));
// Define a mock response handler function
const mockResHandler = jest.fn();
// Define a mock error handler function
const mockErrorHandler = jest.fn();

describe('useFetchHook', () => {
    let originalFetch: any;
    beforeEach(() => {
        originalFetch = global.fetch;
    });
    afterEach(() => {
        global.fetch = originalFetch;
    });
    beforeEach(() => {
        mockResHandler.mockClear();
        mockErrorHandler.mockClear();
    });
    // Test the successful fetch scenario
    it.only('should fetch data and update state accordingly', async () => {
        (fetch as jest.Mock).mockResolvedValueOnce({
            ok: true,
            json: async () => mockTodo
        });
        const { result } = renderHook(() => useFetchHook({ path: mockPath, options: mockOptions }));
        const [fireAPI, apiState] = result.current as [() => Promise<void>, { loading: boolean; data: null | unknown, error: null | unknown }];
        act(() => {
            fireAPI();
        });
        expect(apiState).toEqual({ loading: true, data: null, error: null });
        await waitForNextTick();
        expect(apiState).toEqual({ loading: false, data: mockTodo, error: null });
    })
})