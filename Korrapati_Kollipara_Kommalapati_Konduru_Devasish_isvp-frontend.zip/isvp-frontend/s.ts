import { useState } from 'react';

export interface IFetchHook {
    path: string;
    options?: Record<string, any>;
    resHandler?: (param: any) => void;
    errorHandler?: (obj: Record<string, any>) => void;
}

const getOptions = (params: any) => {
    const defaults = {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    };
    const newObj = {
        ...defaults,
        ...params
    };
    // header is object, all other fields are plain values, recursive merge
    if (params?.headers) {
        newObj.headers = { ...defaults.headers, ...params.headers };
    }
    return newObj;
}; 

const useFetchHook = ({ path = '', options = {}, resHandler, errorHandler }: IFetchHook) => {
    const [apiState, setApiState] = useState({ loading: false, data: null, error: null });
    const fetchOptions = getOptions(options);
    const fireAPI = async () => {
        if (typeof fetch == 'undefined') { throw new Error('fetch not defined'); }
        try {
            setApiState({ loading: true, data: null, error: null });
            const res = await fetch(path, fetchOptions);
            if (resHandler) {
                resHandler(res); setApiState({ loading: false, data: null, error: null });
            } else {
                const parsedRes = await res.json();
                setApiState({ loading: false, data: parsedRes, error: null });
            }
        } catch (error: any) {
            setApiState({
                loading: false, data: null, error
            }); if (errorHandler) {
                errorHandler({ path, fetchOptions, error });
            }
        }
    }
    return [fireAPI, apiState];
}
export default useFetchHook;
