import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  issignedIn:false,
}

export const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    setSignIn: (state) => {
      state.issignedIn = true;
    },
    setSignOut: (state) => {
      state.issignedIn = false;
    },
  },
})

// Action creators are generated for each case reducer function
export const { setSignIn, setSignOut } = authSlice.actions

export default authSlice.reducer;