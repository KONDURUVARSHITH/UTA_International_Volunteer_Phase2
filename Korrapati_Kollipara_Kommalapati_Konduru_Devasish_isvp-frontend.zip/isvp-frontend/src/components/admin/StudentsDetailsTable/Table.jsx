import React, { useMemo }  from "react";
import {Table, TableHeader, TableColumn, TableBody, TableRow, TableCell, Pagination, Spinner, getKeyValue,User, Chip, statusColorMap, Tooltip} from "@nextui-org/react";
import useSWR from "swr";
import { EditIcon } from "../../../icons/EditIcon";
import { DeleteIcon } from "../../../icons/DeleteIcon";
import { EyeIcon } from "../../../icons/EyeIcon";

const fetcher = (...args) => fetch(...args).then((res) => res.json());


export const StudentDetailsTable = () => {
  const [page, setPage] = React.useState(1);

  const {data, isLoading} = useSWR(`https://swapi.py4e.com/api/people?page=${page}`, fetcher, {
    keepPreviousData: true,
  });

  const statusColorMap = {
    active: "success",
    paused: "danger",
    vacation: "warning",
  };
  

  const renderCell = React.useCallback((user, columnKey) => {
    console.log(columnKey);
    const cellValue = user[columnKey];

    switch (columnKey) {
      case "name":
        return (
          <User
            avatarProps={{radius: "lg", src: user.avatar}}
            description={user.email}
            name={cellValue}
          >
            {user.email}
          </User>
        );
      case "role":
        return (
          <div className="flex flex-col">
            <p className="text-bold text-sm capitalize">{cellValue}</p>
            <p className="text-bold text-sm capitalize text-default-400">{user.team}</p>
          </div>
        );
      case "status":
        return (
          <Chip className="capitalize" color={statusColorMap[user.status]} size="sm" variant="flat">
            {cellValue}
          </Chip>
        );
      case "actions":
        return (
          <div className="relative flex items-center gap-2">
            <Tooltip content="Details">
              <span className="text-lg text-default-400 cursor-pointer active:opacity-50">
                <EyeIcon />
              </span>
            </Tooltip>
            <Tooltip content="Edit user">
              <span className="text-lg text-default-400 cursor-pointer active:opacity-50">
                <EditIcon />
              </span>
            </Tooltip>
            <Tooltip color="danger" content="Delete user">
              <span className="text-lg text-danger cursor-pointer active:opacity-50">
                <DeleteIcon />
              </span>
            </Tooltip>
          </div>
        );
      default:
        return cellValue;
    }
  }, []);


  const students = [
    {
        firstName: 'FirstName',
        lastName: 'LastName',
        email: 's1@uta.com',
        phone: '7893637282',
        dob:'13/8/1996',
        yog:'24/5/2024'
    },
    {
        firstName: 'FirstName',
        lastName: 'LastName',
        email: 's2@uta.com',
        phone: '7893637282',
        dob:'13/8/1996',
        yog:'24/5/2024'
    },
    {
        firstName: 'FirstName',
        lastName: 'LastName',
        email: 's3@uta.com',
        phone: '7893637282',
        dob:'13/8/1996',
        yog:'24/5/2024'
    },
    {
        firstName: 'FirstName',
        lastName: 'LastName',
        email: 's4@uta.com',
        phone: '7893637282',
        dob:'13/8/1996',
        yog:'24/5/2024'
    },
    {
        firstName: 'FirstName',
        lastName: 'LastName',
        email: 's5@uta.com',
        phone: '7893637282',
        dob:'13/8/1996',
        yog:'24/5/2024'
    },
    {
        firstName: 'FirstName',
        lastName: 'LastName',
        email: 's6@uta.com',
        phone: '7893637282',
        dob:'13/8/1996',
        yog:'24/5/2024'
    },
    {
        firstName: 'FirstName',
        lastName: 'LastName',
        email: 's7@uta.com',
        phone: '7893637282',
        dob:'13/8/1996',
        yog:'24/5/2024'
    },
    {
        firstName: 'FirstName',
        lastName: 'LastName',
        email: 's8@uta.com',
        phone: '7893637282',
        dob:'13/8/1996',
        yog:'24/5/2024'
    },
    {
        firstName: 'FirstName',
        lastName: 'LastName',
        email: 's9@uta.com',
        phone: '7893637282',
        dob:'13/8/1996',
        yog:'24/5/2024'
    },
    {
        firstName: 'FirstName',
        lastName: 'LastName',
        email: 's10@uta.com',
        phone: '7893637282',
        dob:'13/8/1996',
        yog:'24/5/2024'
    }

  ]
  console.log(data);

  const rowsPerPage = 10;

  const pages = useMemo(() => {
    return data?.count ? Math.ceil(data.count / rowsPerPage) : 0;
  }, [data?.count, rowsPerPage]);

  const loadingState = isLoading || data?.results.length === 0 ? "loading" : "idle";

  return (
    <Table
      aria-label="Example table with client async pagination"
      bottomContent={
        pages > 0 ? (
          <div className="flex w-full justify-center">
            <Pagination
              isCompact
              showControls
              showShadow
              color="primary"
              page={page}
              total={pages}
              onChange={(page) => setPage(page)}
            />
          </div>
        ) : null
      }
    >
      <TableHeader>
        <TableColumn key="firstName">First Name</TableColumn>
        <TableColumn key="lastName">Last Name</TableColumn>
        <TableColumn key="email">Email</TableColumn>
        <TableColumn key="phone">Phone</TableColumn>
        <TableColumn key="dob">Date of Birth</TableColumn>
        <TableColumn key="yog">Year of Graduation</TableColumn>
        <TableColumn key="actions">Actions</TableColumn>
      </TableHeader>
      <TableBody
        items={ students ?? []}
        loadingContent={<Spinner />}
        loadingState={loadingState}
      >
        {(student) => (
          <TableRow key={student?.email}>

            {(columnKey) => <TableCell>{renderCell(student, columnKey)}</TableCell>}
          </TableRow>
        )}
      </TableBody>
    </Table>
  );
}
