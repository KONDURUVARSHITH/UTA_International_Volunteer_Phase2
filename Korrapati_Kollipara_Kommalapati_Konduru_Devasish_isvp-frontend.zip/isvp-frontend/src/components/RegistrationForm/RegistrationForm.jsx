import { Button, Input } from "@nextui-org/react";
import React from "react";
import styles from "./RegistrationForm.module.css";

export const RegistrationForm = () => {
  return (
    <div>
      <div className={styles.input}>
        <div className={styles.subInput}>
          <Input
            labelPlacement="outside"
            type="text"
            label="First Name"
            placeholder="Enter your first name"
          />
        </div>
        <div className={styles.subInput}>
          <Input
            labelPlacement="outside"
            type="text"
            label="LastName"
            placeholder="Enter your last name"
          />
        </div>
      </div>
      <div className={styles.input}>
        <div className={styles.subInput}>
          <Input
            labelPlacement="outside"
            type="number"
            label="Phone"
            placeholder="Enter your phone number"
          />
        </div>
        <div className={styles.subInput}>
          <Input
            labelPlacement="outside"
            type="email"
            label="Email"
            placeholder="Enter your email"
          />
        </div>
      </div>
      <div className={styles.input}>
        <div className={styles.subInput}>
          <Input
            labelPlacement="outside"
            type="password"
            label="Password"
            placeholder="Enter your password"
          />
        </div>
        <div className={styles.subInput}>
          <Input
            labelPlacement="outside"
            type="password"
            label="Confirm Password"
            placeholder="Enter your password"
          />
        </div>
      </div>
      <div className={styles.input}>
        <div className={styles.subInput}>
          <Input
            labelPlacement="outside"
            type="date"
            label="Date of Birth"
            placeholder="Enter your password"
          />
        </div>
        <div className={styles.subInput}>
          <Input
            labelPlacement="outside"
            type="date"
            label="Graduate Year"
            placeholder="Enter your password"
          />
        </div>
      </div>
      <div className={styles.button}>
        <Button color="primary" variant="shadow">
        Register
    </Button>
      </div>
   
    </div>
  );
};
