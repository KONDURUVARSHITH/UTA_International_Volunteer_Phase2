import React from "react";
import {Card, CardHeader, CardBody, CardFooter, Divider, Image, Chip, Tooltip} from "@nextui-org/react";
import styles from './Card.module.css';
import { EditIcon } from "../../icons/EditIcon";
import { DeleteIcon } from "../../icons/DeleteIcon";

export function TaskCard({isProfessor}) {
  return (
    <Card className="max-w-[400px]" >
      <CardHeader className="flex gap-3">
        <Image
          alt="nextui logo"
          height={40}
          radius="sm"
          src="https://avatars.githubusercontent.com/u/86160567?s=200&v=4"
          width={40}
        />

        <div className="flex flex-col">
          <p className="text-md">Task</p>
          <p className="text-small text-default-500">Headline</p>
        </div>
        {isProfessor && 
        <div style={{display:'flex', gap: '10px', marginLeft: '95px' }}>
        <Tooltip content="Edit Task">
              <span className="text-lg text-default-400 cursor-pointer active:opacity-50">
                <EditIcon />
              </span>
            </Tooltip>
            <Tooltip color="danger" content="Delete Task">
              <span className="text-lg text-danger cursor-pointer active:opacity-50">
                <DeleteIcon />
              </span>
            </Tooltip>
        </div> }
      </CardHeader>
      <Divider/>
      <CardBody>
        <p>Task Description: Make beautiful websites regardless of your design experience.</p>
      </CardBody>
      <Divider/>
      <CardFooter>
        <div className={styles.footerStatus}>
       <p>
        Status: 
       </p>
       <Chip color="primary"> Ready</Chip>
       </div>
       <div className={styles.footerDeadline}>
       <p >
        Deadline: 
       </p>
       <Chip>DD/MM/YYYY</Chip>
       </div>
      </CardFooter>
    </Card>
  );
}
