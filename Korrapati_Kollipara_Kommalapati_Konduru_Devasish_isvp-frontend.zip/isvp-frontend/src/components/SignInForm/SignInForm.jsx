import { Input, Button, Chip } from "@nextui-org/react";
import styles from "./SignInForm.module.css";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch } from 'react-redux'
import { setSignIn } from "../../redux/store/auth";

export const SignInForm = () => {
    const [email,setEmail] = useState();
    const [password, setPassword] = useState();
    const [isInvalid,setIsInvalid] = useState(false);
    const navigate = useNavigate();
    const dispatch = useDispatch()
 
    const handleOnSubmit = () => {
      if(email === "student@uta.com" && password === "password"){
        navigate('/student/dashboard');
        dispatch(setSignIn())
      }else if(email === "professor@uta.com" && password === "password"){
        navigate('/professor/dashboard');
        dispatch(setSignIn())
      }else if(email === "admin@uta.com" && password === "password"){
        navigate('/admin/professorsDetails');
        dispatch(setSignIn())
      }else{
        setIsInvalid(true);
      }
    }
    return(
        <div className={styles.wrapper}>
            <div className={styles.input}>
            <Input
            labelPlacement="outside"
            type="email"
            label="Email"
            placeholder="Enter your email"
            onChange={(e) => setEmail(e.target.value)}
          />
            </div>
            <div className={styles.input}>
            <Input
            labelPlacement="outside"
            type="password"
            label="Password"
            placeholder="Enter your password"
            onChange={(e) => setPassword(e.target.value)}
          />
          </div>
          { isInvalid && <div className={styles.input}>
            <Chip radius="sm" size="md" color="danger">Please provide valid credentails</Chip>
          </div> }
          <div className={styles.button}>
        <Button color="primary" variant="shadow" onClick={handleOnSubmit}>
        Sign In
    </Button>
    </div>
        </div>
    )
}