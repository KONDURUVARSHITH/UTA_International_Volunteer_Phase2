import './App.css';
import AppRouter from './appRouter';
import { Layout } from './layouts/Layout';

function App() {
  return (
      <Layout>
        <AppRouter/>
      </Layout>
  );
}

export default App;
