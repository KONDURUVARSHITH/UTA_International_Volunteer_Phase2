import React from "react";
import styles from "./StudentDetails.module.css";
import { Navbar } from "../../../components/admin/Navbar/Navbar";
import { StudentDetailsTable } from "../../../components/admin/StudentsDetailsTable";
import { useDispatch } from "react-redux";
import { useEffect } from "react";
import { setSignIn } from "../../../redux/store/auth";
import { Button, Input } from "@nextui-org/react";

export const StudentDetails = () => {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(setSignIn());
  }, []);
  return (
    <div>
      <div className={styles.actionWrapper}>
        <div className={styles.professorName}>
          <h1>Welcome Admin</h1>
        </div>
        <div className={styles.actionBar}></div>
      </div>
      <div className={styles.container}>
        <div className={styles.navBar}>
          <Navbar />
        </div>
        <div className={styles.component}>
          <div className={styles.form}>
            <div className={styles.heading}>
              <h1>Students Details</h1>
            </div>
            <div className={styles.subHeading}>
              <h2>Know About your Students</h2>
            </div>
            <div className={styles.filter} >
            <div className={styles.create}> 
                <Button variant="solid" size="xs" color="primary">
                  Create
                </Button>
              </div>
              <div className={styles.search}>
                <div>
                  <Input size="xs"  placeholder="Search for student"/>
                </div>
                <div>
                  <Button variant="bordered" color="primary"> Search </Button>
                </div>
              </div>
            </div>
            <div className={styles.info}>
              <StudentDetailsTable />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
