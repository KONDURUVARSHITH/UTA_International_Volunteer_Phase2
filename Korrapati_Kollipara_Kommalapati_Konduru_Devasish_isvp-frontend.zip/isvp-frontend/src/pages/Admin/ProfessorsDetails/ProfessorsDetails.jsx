import React from "react";
import styles from './ProfessorsDetails.module.css';
import { Navbar } from "../../../components/admin/Navbar/Navbar";
import { ProfessorsDetailsTable } from "../../../components/admin/ProfessorsDetailsTable";
import { useDispatch } from "react-redux";
import { useEffect } from "react";
import { setSignIn } from "../../../redux/store/auth";
import { Button, Input,  } from "@nextui-org/react";
export const ProfessorsDetails = () => {
  const dispatch = useDispatch();
    useEffect(() => {
        dispatch(setSignIn());
    },[]);
  return (
    <div>
      <div className={styles.actionWrapper}>
        <div className={styles.professorName}>
          <h1>Welcome Admin</h1>
        </div>
        <div className={styles.actionBar}>
      </div></div>
      <div className={styles.container}>
      <div className={styles.navBar}>
          <Navbar/>
      </div>
      <div className={styles.component}>
      <div className={styles.form}>
            <div className={styles.heading}>
            <h1>
              Professors Details
            </h1>
            </div>
            <div className={styles.subHeading}>
              <h2>
                Know About Professors
              </h2>
            </div>
            <div className={styles.filter} >
            <div className={styles.create}> 
                <Button variant="solid" size="xs" color="primary">
                  Create
                </Button>
              </div>
              <div className={styles.search}>
                <div>
                  <Input size="xs"  placeholder="Search for professor"/>
                </div>
                <div>
                  <Button variant="bordered" color="primary"> Search </Button>
                </div>
              </div>
            </div>
            <div className={styles.info}>
            <ProfessorsDetailsTable />
            </div>
            </div>
      </div>
      </div>
    </div>
  );
}
