import React from "react";
import { Select, SelectItem, Input, Button} from "@nextui-org/react";
import styles from './Assign.module.css';
import { Navbar } from "../../../components/admin/Navbar/Navbar";

export const Assign = () => {
  const reasons = [
    {id:1, label:'Professor 1', value:'Professor1'},
    {id:2,  label:'Professor 2', value:'Professor2'},
    {id:3,  label:'Professor 3', value:'Professor3'},
    {id:4,  label:'Professor 4', value:'Professor4'},
    {id:5, label:'Professor 5', value:'Professor5'},
    {id:6,  label:'Professor 6', value:'Professor26'},
  ];

  return (
    <div>
      <div className={styles.actionWrapper}>
        <div className={styles.professorName}>
          <h1>Welcome Admin</h1>
        </div>
       </div>
      <div className={styles.container}>
      <div className={styles.navBar}>
        <Navbar />
      </div>
      <div className={styles.component}>
      <div className={styles.form}>
            <div className={styles.heading}>
            <h1>
              Assign 
            </h1>
            </div>
            <div className={styles.subHeading}>
              <h2>
                Assign professor to the student.
              </h2>
            </div>
            <div className={styles.info}>
              <h3>Professors</h3>
              <div className={styles.reasons}>
                <Select
                  className={styles.select}
                  label="Professor"
                  placeholder="Select a Professor"
                >
                  {reasons.map((task) => (
                    <SelectItem key={task.value} value={task.value}>
                      {task.label}
                    </SelectItem>
                  ))}
                </Select>
              </div>
            </div>
            <div className={styles.info}>
            <h3>Student Email Id</h3>
            <div className={styles.fileUpload}>
                <Input  className={styles.input} size="xs"/>
                <Button variant="bordered" color="primary">Assign Professor</Button>
              </div>
            </div>
      </div>
      </div>
      </div>
      </div>
  );
}
