import React from "react";
import { Button, Input, Snippet, Select, SelectItem } from "@nextui-org/react";
import styles from "./Chat.module.css";
import { Navbar } from "../../../components/student/Navbar/Navbar";

export const Chat = () => {
  const recipients = [
    { label: "Person 1", value: "person1" },
    { label: "Person 2", value: "person2" },
    { label: "Person 3", value: "person3" },
    { label: "Person 4", value: "person4" },
  ];

  return (
    <div>
      <div className={styles.actionWrapper}>
        <div className={styles.professorName}>
          <h1>Hello!!! Student Name</h1>
        </div>
      </div>
      <div className={styles.container}>
        <div className={styles.navBar}>
          <Navbar />
        </div>
        <div className={styles.component}>
          <div className={styles.form}>
            <div className={styles.heading}>
              <h1>Conversations</h1>
            </div>
            <div className={styles.subHeading}>
              <h2>Let's connect with people</h2>
            </div>
            <div className={styles.chatContainer}>
              <div className={styles.task}>
                <Select
                  
                  placeholder="Select a Recipient"
                  label="Recipients"
                >
                  {recipients.map((recipient) => (
                    <SelectItem key={recipient.value} value={recipient.value}>
                      {recipient.label}
                    </SelectItem>
                  ))}
                </Select>
              </div>
              <div className={styles.chatBox}>
                <div className={`${styles.chatMessage} ${styles.received}`}>
                  <Snippet
                    hideCopyButton
                    hideSymbol
                    color="default"
                    variant="solid"
                  >
                    Hello there!
                  </Snippet>
                </div>
                <div className={`${styles.chatMessage} ${styles.sent}`}>
                  <Snippet
                    hideCopyButton
                    hideSymbol
                    color="primary"
                    variant="solid"
                  >
                    Hi! How can I help you?
                  </Snippet>
                </div>
              </div>
              <div className={styles.input}>
                <Input
                  type="text"
                  placeholder="Type your message..."
                  size="xs"
                />
                <Button color="primary" variant="bordered">
                  Send
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
