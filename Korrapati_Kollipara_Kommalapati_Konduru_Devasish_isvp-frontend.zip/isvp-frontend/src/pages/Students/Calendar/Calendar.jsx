import React from "react";
import { Select, SelectItem} from "@nextui-org/react";
import styles from './Calendar.module.css';
import { Navbar } from "../../../components/student/Navbar/Navbar";
import FullCalendar from '@fullcalendar/react'
import dayGridPlugin from '@fullcalendar/daygrid';

export const Calendar = () => {

  const sortValues = [
    {label:'All' , value:'all'},
    {label:'Deadline', value:'deadline'},
    {label:'Status', value:'status'}
  ]
  return (
    <div>
      <div className={styles.actionWrapper}>
        <div className={styles.professorName}>
          <h1>Hello!!! Student Name</h1>
        </div>
        <div className={styles.actionBar}>
      <div className={styles.createTask}>
      {/* <Button color="primary">
        Create Task
      </Button> */}
      </div>
      </div></div>
      <div className={styles.container}>
      <div className={styles.navBar}>
        <Navbar />
      </div>
      <div className={styles.component}>
      <FullCalendar
  plugins={[ dayGridPlugin ]}
  initialView="dayGridMonth"
  weekends={false}
  styles={{minWidth: '-webkit-fill-available'}}
  events={[
    { title: 'event 1', date: '2019-04-01' },
    { title: 'event 2', date: '2019-04-02' }
  ]}
/>
      </div>
      </div>
    </div>
  );
}
