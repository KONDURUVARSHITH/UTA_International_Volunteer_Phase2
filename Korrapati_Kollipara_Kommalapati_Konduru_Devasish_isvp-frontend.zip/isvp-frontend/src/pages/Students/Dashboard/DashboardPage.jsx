import React from "react";
import { Select, SelectItem} from "@nextui-org/react";
import styles from './Dashboard.module.css';
import { TaskCard } from "../../../components/Card";
import { Navbar } from "../../../components/student/Navbar/Navbar";
import { useDispatch } from "react-redux";
import { useEffect } from "react";
import { setSignIn } from "../../../redux/store/auth";

export const Dashboard = () => {

  const dispatch = useDispatch();
    useEffect(() => {
        dispatch(setSignIn());
    },[]);
    
  const tasks = [
    {id:1},
    {id:2},
    {id:3},
    {id:4},
    {id:5},
    {id:6},
  ];

  const sortValues = [
    {label:'All' , value:'all'},
    {label:'Deadline', value:'deadline'},
    {label:'Status', value:'status'}
  ]
  return (
    <div>
      <div className={styles.actionWrapper}>
        <div className={styles.professorName}>
          <h1>Hello!!! Student Name</h1>
        </div>
        <div className={styles.actionBar}>
      <div className={styles.sort}>
      <Select 
        size="xs"
        label="Sort Type" 
      >
        {sortValues.map((sortValue) => (
          <SelectItem key={sortValue.value} value={sortValue.value}>
            {sortValue.label}
          </SelectItem>
        ))}
      </Select>
      
      </div>
      <div className={styles.createTask}>
      {/* <Button color="primary">
        Create Task
      </Button> */}
      </div>
      </div></div>
      <div className={styles.container}>
      <div className={styles.navBar}>
        <Navbar />
      </div>
      <div className={styles.component}>
          {tasks.map((task) => (
            <div className={styles.card}>
          <TaskCard isProfessor={false}/>
          </div>
          ))}
      </div>
      </div>
    </div>
  );
}
