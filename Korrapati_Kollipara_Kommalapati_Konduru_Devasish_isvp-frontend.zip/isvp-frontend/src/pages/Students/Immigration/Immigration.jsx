import React from "react";
import { Select, SelectItem, Input, Button} from "@nextui-org/react";
import styles from './Immigration.module.css';
import { Navbar } from "../../../components/student/Navbar/Navbar";

export const Immigration = () => {
  const reasons = [
    {id:1, label:'Reason 1', value:'reason1'},
    {id:2,  label:'Reason 2', value:'reason2'},
    {id:3,  label:'Reason 3', value:'reason3'},
    {id:4,  label:'Reason 4', value:'reason4'},
    {id:5, label:'Reason 5', value:'reason5'},
    {id:6,  label:'Reason 6', value:'reason6'},
  ];

  return (
    <div>
      <div className={styles.actionWrapper}>
        <div className={styles.professorName}>
          <h1>Hello!!! Student Name</h1>
        </div>
       </div>
      <div className={styles.container}>
      <div className={styles.navBar}>
        <Navbar />
      </div>
      <div className={styles.component}>
      <div className={styles.form}>
            <div className={styles.heading}>
            <h1>
              Immigration
            </h1>
            </div>
            <div className={styles.subHeading}>
              <h2>
                Know About your Immigration details
              </h2>
            </div>
            <div className={styles.info}>
              <h3>
                Your visa status
              </h3>
              <p>F1-OPT</p>
            </div>
            <div className={styles.info}>
              <h3>
                Your volunteer program status
              </h3>
              <p>In Progress</p>
            </div>
            <div className={styles.info}>
              <h3>
                For release or recommendation letter from supervisor for any opportunities, please submit your request below
              </h3>
            </div>
            <div className={styles.info}>
              <h3>Reason</h3>
              <div className={styles.reasons}>
                <Select
                  className={styles.select}
                  label="Reason"
                  placeholder="Select a Reason"
                >
                  {reasons.map((task) => (
                    <SelectItem key={task.value} value={task.value}>
                      {task.label}
                    </SelectItem>
                  ))}
                </Select>
              </div>
            </div>
            <div className={styles.info}>
            <h3>Report</h3>
            <div className={styles.fileUpload}>
                <Input type="file" className={styles.input} size="xs"/>
                <Button variant="bordered" color="primary">File Upload</Button>
              </div>
            </div>
            <div className={styles.submit}>
                <Button variant="shadow" color="primary">Submit</Button>
            </div>
      </div>
      </div>
      </div>
      </div>
  );
}
