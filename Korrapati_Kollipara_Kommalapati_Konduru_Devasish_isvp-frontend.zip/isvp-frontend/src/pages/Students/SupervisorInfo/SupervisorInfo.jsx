import React from "react";
import styles from './SupervisorInfo.module.css';
import { Navbar } from "../../../components/student/Navbar/Navbar";

export const SupervisorInfo = () => {

  return (
    <div>
      <div className={styles.actionWrapper}>
        <div className={styles.professorName}>
          <h1>Hello!!! Student Name</h1>
        </div>
      </div>
      <div className={styles.container}>
      <div className={styles.navBar}>
        <Navbar />
      </div>
      <div className={styles.component}>
          <div className={styles.form}>
            <div className={styles.heading}>
            <h1>
              Super Visor Info
            </h1>
            </div>
            <div className={styles.subHeading}>
              <h2>
                Know About your SuperVisor
              </h2>
            </div>
            <div className={styles.info}>
              <h3>
                Professor Name
              </h3>
              <p>Johnny Tins</p>
            </div>
            <div className={styles.info}>
              <h3>
                Designation
              </h3>
              <p>Senior Professor</p>
            </div>
            <div className={styles.info}>
              <h3>
                Email
              </h3>
              <p>tins@jonny.com</p>
            </div>
            <div className={styles.info}>
              <h3>
                Phone Number
              </h3>
              <p>+1 2343 783 233</p>
            </div>
            <div className={styles.info}>
              <h3>
                Work Hours
              </h3>
              <p>9:00AM-6:AM</p>
            </div>
          </div>
      </div>
      </div>
    </div>
  );
}
