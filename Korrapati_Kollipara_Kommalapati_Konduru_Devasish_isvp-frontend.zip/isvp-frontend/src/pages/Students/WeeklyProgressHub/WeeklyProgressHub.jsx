import React from "react";
import { Input, Select, SelectItem, Textarea, Button } from "@nextui-org/react";
import styles from './WeeklyProgressHub.module.css';
import { Navbar } from "../../../components/student/Navbar/Navbar";

export const WeeklyProgressHub = () => {
  const tasks = [
    { id: 1, value: 'task1', label: 'Task 1' },
    { id: 2, value: 'task2', label: 'Task 2' },
    { id: 3, value: 'task3', label: 'Task 3' },
    { id: 4, value: 'task4', label: 'Task 4' },
    { id: 5, value: 'task5', label: 'Task 5' },
    { id: 6, value: 'task6', label: 'Task 6' },
  ];

  return (
    <div>
      <div className={styles.actionWrapper}>
        <div className={styles.professorName}>
          <h1>Hello!!! Student Name</h1>
        </div>
      </div>
      <div className={styles.container}>
        <div className={styles.navBar}>
          <Navbar />
        </div>
        <div className={styles.component}>
          <div className={styles.form}>
            <div className={styles.heading}>
              <h1>
                Weekly Process hub
              </h1>
            </div>
            <div className={styles.subHeading}>
              <h2>
                Week 2
              </h2>
            </div>
            
              <div className={styles.task}>
                <Select
                  className={styles.select}
                  label="Tasks"
                  placeholder="Select a Task"
                >
                  {tasks.map((task) => (
                    <SelectItem key={task.value} value={task.value}>
                      {task.label}
                    </SelectItem>
                  ))}
                </Select>
              </div>
              <div className={styles.justifyComments}>
                <Textarea
                  className={styles.textArea}
                  label="Description"
                  labelPlacement="outside"
                  placeholder="Enter your description"
                  defaultValue="NextUI is a React UI library that provides a set of accessible, reusable, and beautiful components."
                />
              </div>

              <div className={styles.fileUpload}>
                <Input type="file" className={styles.input} size="xs"/>
                <Button variant="bordered" color="primary">File Upload</Button>
              </div>
              <div className={styles.submit}>
                <Button variant="shadow" color="primary">Submit</Button>
              </div>
          </div>
        </div>
      </div>
    </div>
  );
}
