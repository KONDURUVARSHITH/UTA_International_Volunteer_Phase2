import React from "react"
import styles from './ContactUs.module.css';
import { Button, Image, Input, Textarea } from "@nextui-org/react";
export const ContactUs = () => {
    return (
        <div className={styles.contactUs}>
            <h1>
                How can we help you?  
            </h1>
            <p className={styles.description}>Thank you for your interest in ISVP. Please use this form to contact us. We will get back to you as soon as we can.</p>
            <div className={styles.contactUsInfo}>
            <div className={styles.image}>
                <Image src={'/contact-us.webp'} width={'500px'} height={'300px'} />
            </div>
            <div className={styles.info}>
                <div className={styles.form}>
                <Input type="text" className={styles.name} label="Name" size="s"/>
                <Input type="email" className={styles.email} label="Email" size="s"/>
                <Textarea label="Description" className={styles.description} size="s"/>
                <Button color="primary" variant="bordered" className={styles.submit} size="s">Submit</Button>
                </div>
            </div>
            </div>
        </div>
    )
}