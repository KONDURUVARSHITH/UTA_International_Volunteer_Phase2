import React from "react";
import styles from "./AssesmentCenter.module.css";
import { Navbar } from "../../../components/professor/Navbar/Navbar";
import {
  Select,
  SelectItem,
  Accordion,
  AccordionItem,
  Textarea,
  Button,
} from "@nextui-org/react";
export const AssesmentCenter = () => {
  const tasks = [
    { label: "All", value: "all" },
    { label: "Deadline", value: "deadline" },
    { label: "Status", value: "status" },
  ];

  const assesments = [
    { title: "Student Name 1", subTitle: "Submitted on mm/dd/yyyy" },
    { title: "Student Name 2", subTitle: "Submitted on mm/dd/yyyy" },
    { title: "Student Name 3", subTitle: "Submitted on mm/dd/yyyy" },
    { title: "Student Name 4", subTitle: "Submitted on mm/dd/yyyy" },
  ];
  const defaultContent =
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.";

  return (
    <div>
      <div className={styles.actionWrapper}>
        <div className={styles.professorName}>
          <h1>Hello!!! Professor Name</h1>
        </div>
        <div className={styles.actionBar}></div>
      </div>
      <div className={styles.container}>
        <div className={styles.navBar}>
          <Navbar />
        </div>
        <div className={styles.component}>
          <div className={styles.form}>
            <div className={styles.heading}>
              <h1>Assesment Center</h1>
            </div>
            <div className={styles.subHeading}>
              <h2>Provide your feedback to your assesment.</h2>
            </div>
            <div className={styles.info}>
              <h3>Choose Task</h3>
              <Select size="xs" placeholder="Select Task" className={styles.tasks}>
                {tasks.map((task) => (
                  <SelectItem key={task.value} value={task.value}>
                    {task.label}
                  </SelectItem>
                ))}
              </Select>
            </div>
            <div className={styles.info}>
              <Accordion variant="bordered">
                {assesments.map((assesment, index) => (
                  <AccordionItem
                    key={index}
                    aria-label={assesment.title}
                    title={assesment.title}
                    subtitle={assesment.subTitle}
                  >
                    <Textarea 
                    labelPlacement="outside"
                    placeholder="Provide your feedback"
                     className={styles.feedback}label="Feedback" size="s" />
                    <Button className={styles.post} variant="bordered" color="primary">Post </Button>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
