import React from "react";
import styles from "./CreateTask.module.css";
import { Navbar } from "../../../components/professor/Navbar/Navbar";
import {
  Input,
    Textarea,
    Button
} from "@nextui-org/react";
export const CreateTask = () => {
  const tasks = [
    { label: "All", value: "all" },
    { label: "Deadline", value: "deadline" },
    { label: "Status", value: "status" },
  ];

  const assesments = [
    { title: "Student Name 1", subTitle: "Submitted on mm/dd/yyyy" },
    { title: "Student Name 2", subTitle: "Submitted on mm/dd/yyyy" },
    { title: "Student Name 3", subTitle: "Submitted on mm/dd/yyyy" },
    { title: "Student Name 4", subTitle: "Submitted on mm/dd/yyyy" },
  ];
  const defaultContent =
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.";

  return (
    <div>
      <div className={styles.actionWrapper}>
        <div className={styles.professorName}>
          <h1>Hello!!! Professor Name</h1>
        </div>
        <div className={styles.actionBar}></div>
      </div>
      <div className={styles.container}>
        <div className={styles.navBar}>
          <Navbar />
        </div>
        <div className={styles.component}>
          <div className={styles.form}>
            <div className={styles.heading}>
              <h1>Create Task</h1>
            </div>
            <div className={styles.subHeading}>
              <h2>Enter the details to create a new task</h2>
            </div>
            <div className={styles.info} style={{marginTop: '40px'}}>
              <Input
            labelPlacement="outside"
            type="text"
            label="Title"
            placeholder="Provide the task title"
          />
            </div>
            <div className={styles.info}>
              <Textarea 
                    labelPlacement="outside"
                    placeholder="Provide the task description"
                    label="Description" size="s" />
            </div>
            <div className={styles.info}>
                <Input type="date" label="Deadline" placeholder="Please choose the deadline date"/>
            </div>
            <div className={styles.info}>
            <Button color="primary" variant="bordered" style={{float:'right'}}>
        Create
    </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
