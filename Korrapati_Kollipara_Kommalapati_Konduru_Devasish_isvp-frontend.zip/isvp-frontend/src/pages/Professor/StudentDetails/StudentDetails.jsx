import React from "react";
import styles from './StudentDetails.module.css';
import { Navbar } from "../../../components/professor/Navbar/Navbar";
import { StudentDetailsTable } from "../../../components/professor/Table/Table";

export const StudentDetails = () => {

  return (
    <div>
      <div className={styles.actionWrapper}>
        <div className={styles.professorName}>
          <h1>Hello!!! Professor Name</h1>
        </div>
        <div className={styles.actionBar}>
      </div></div>
      <div className={styles.container}>
      <div className={styles.navBar}>
          <Navbar/>
      </div>
      <div className={styles.component}>
      <div className={styles.form}>
            <div className={styles.heading}>
            <h1>
              Students Details
            </h1>
            </div>
            <div className={styles.subHeading}>
              <h2>
                Know About your Students
              </h2>
            </div>
            <div className={styles.info}>
            <StudentDetailsTable />
            </div>
            </div>
      </div>
      </div>
    </div>
  );
}
