import React from "react";
import styles from "./RLGenerator.module.css";
import { Navbar } from "../../../components/professor/Navbar/Navbar";
import {
  Select,
  SelectItem,
  Accordion,
  AccordionItem,
  Textarea,
  Button,
  Link,
} from "@nextui-org/react";
export const RLGenerator = () => {

  const assesments = [
    { title: "Student Name 1", subTitle: "Submitted on mm/dd/yyyy" },
    { title: "Student Name 2", subTitle: "Submitted on mm/dd/yyyy" },
    { title: "Student Name 3", subTitle: "Submitted on mm/dd/yyyy" },
    { title: "Student Name 4", subTitle: "Submitted on mm/dd/yyyy" },
  ];

  return (
    <div>
      <div className={styles.actionWrapper}>
        <div className={styles.professorName}>
          <h1>Hello!!! Professor Name</h1>
        </div>
        <div className={styles.actionBar}></div>
      </div>
      <div className={styles.container}>
        <div className={styles.navBar}>
          <Navbar />
        </div>
        <div className={styles.component}>
          <div className={styles.form}>
            <div className={styles.heading}>
              <h1>Recommendation Letter</h1>
            </div>
            <div className={styles.subHeading}>
              <h2>Request for recommendation letter.</h2>
            </div>
            <div className={styles.info}>
              <Accordion variant="bordered">
                {assesments.map((assesment, index) => (
                  <AccordionItem
                    key={index}
                    aria-label={assesment.title}
                    title={assesment.title}
                    subtitle={assesment.subTitle}
                  >

<div className={styles.info}>
              <h3>Reason</h3>
              <p type="link" href=".">Got Opportunity</p>
            </div>
                    <div className={styles.info}>
              <h3>Documents</h3>
              <Link type="link" href=".">Student Offer Letter</Link>
            </div>
                    <Textarea 
                    labelPlacement="outside"
                    placeholder="Provide your feedback"
                     className={styles.feedback}label="Feedback" size="s" />
                    <Button className={styles.post} variant="bordered" color="primary">Post </Button>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
