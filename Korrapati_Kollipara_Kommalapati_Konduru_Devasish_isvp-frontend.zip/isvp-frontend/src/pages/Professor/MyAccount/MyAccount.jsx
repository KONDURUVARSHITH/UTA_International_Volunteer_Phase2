import React from "react";
import { Button, Input } from "@nextui-org/react";
import styles from './MyAccount.module.css';
import { Navbar } from "../../../components/professor/Navbar/Navbar";

export const MyAccount = () => {

  return (
    <div>
      <div className={styles.actionWrapper}>
        <div className={styles.professorName}>
          <h1>Hello!!! Professor Name</h1>
        </div>
      </div>
      <div className={styles.container}>
        <div className={styles.navBar}>
          <Navbar />
        </div>
        <div className={styles.component}>

          <div className={styles.form}>
            <div className={styles.heading}>
              <h1>
                My Account
              </h1>
            </div>
            <div className={styles.subHeading}>
              <h2>
                Know about your account details
              </h2>
            </div>
            <div className={styles.info}>
              <h3>
                First Name
              </h3>
              <p>Professor First Name</p>
            </div>
            <div className={styles.info}>
              <h3>
                Last Name
              </h3>
              <p>Professor Last Name</p>
            </div>
            <div className={styles.info}>
              <h3>
                Phone Number
              </h3>
              <p>+1 2344 54 4231</p>
            </div>
            <div className={styles.info}>
              <h3>
                Email
              </h3>
              <p>professor@uta.com</p>
            </div>
            <div className={styles.info}>
              <h3>
                Date of Birth
              </h3>
              <p>29-Feb-1996</p>
            </div>
              <div className={styles.info}>
              <h3>Update Password</h3>
              <div className={styles.input}>
                <div className={styles.subInput}>
                  <Input
                    labelPlacement="inside"
                    type="password"
                    label="Password"
                    placeholder="Enter your password"
                  />
                </div>
                <div className={styles.subInput}>
                  <Input
                    labelPlacement="inside"
                    type="password"
                    label="Confirm Password"
                    placeholder="Enter your password"
                  />
                </div>
              </div>
              <div className={styles.button}>
                <Button color="primary" variant="shadow">
                  Update
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
